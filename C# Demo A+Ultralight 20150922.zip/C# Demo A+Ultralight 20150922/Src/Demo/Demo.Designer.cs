﻿namespace Demo
{
    partial class dlgDemo
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.tabCtrlDemo = new System.Windows.Forms.TabControl();
            this.tp_setparam = new System.Windows.Forms.TabPage();
            this.gb_setparam_buzzer = new System.Windows.Forms.GroupBox();
            this.btn_sp_buzzer_set = new System.Windows.Forms.Button();
            this.tb_sp_buzzer_num = new System.Windows.Forms.TextBox();
            this.lb_sp_buzzer_time = new System.Windows.Forms.Label();
            this.tb_sp_buzzer_time = new System.Windows.Forms.TextBox();
            this.lb_sp_buzzer_num = new System.Windows.Forms.Label();
            this.gb_setparam_led = new System.Windows.Forms.GroupBox();
            this.btn_sp_led_set = new System.Windows.Forms.Button();
            this.tb_sp_led_num = new System.Windows.Forms.TextBox();
            this.tb_sp_led_time = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.lb_sp_led_time = new System.Windows.Forms.Label();
            this.gb_setparam_bm = new System.Windows.Forms.GroupBox();
            this.gb_setparam_setaddress = new System.Windows.Forms.GroupBox();
            this.btn_setparam_setaddress = new System.Windows.Forms.Button();
            this.cob_sp_address = new System.Windows.Forms.ComboBox();
            this.label34 = new System.Windows.Forms.Label();
            this.btn_setparam_read = new System.Windows.Forms.Button();
            this.btn_sp_close = new System.Windows.Forms.Button();
            this.btn_sp_open = new System.Windows.Forms.Button();
            this.btn_setparam_clear = new System.Windows.Forms.Button();
            this.gb_setparam_pm = new System.Windows.Forms.GroupBox();
            this.tb_sp_message = new System.Windows.Forms.TextBox();
            this.btn14443_get = new System.Windows.Forms.TabPage();
            this.gb14443A_cmd = new System.Windows.Forms.GroupBox();
            this.btn14443A_send = new System.Windows.Forms.Button();
            this.tb14443A_cmd = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.cob14443A_crc = new System.Windows.Forms.ComboBox();
            this.lb14443A_crc = new System.Windows.Forms.Label();
            this.tb14443A_length = new System.Windows.Forms.TextBox();
            this.lb14443A_length = new System.Windows.Forms.Label();
            this.gb14443A_ep = new System.Windows.Forms.GroupBox();
            this.btn14443A_initial = new System.Windows.Forms.Button();
            this.btn14443A_decrement = new System.Windows.Forms.Button();
            this.btn14443A_increment = new System.Windows.Forms.Button();
            this.tb14443A_key_ep = new System.Windows.Forms.TextBox();
            this.lb14443A_key_ep = new System.Windows.Forms.Label();
            this.tb14443A_value = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.cob14443A_mode_ep = new System.Windows.Forms.ComboBox();
            this.lb14443A_mode_ep = new System.Windows.Forms.Label();
            this.cob14443A_sector = new System.Windows.Forms.ComboBox();
            this.lb14443A_sector = new System.Windows.Forms.Label();
            this.gb14443A_wr = new System.Windows.Forms.GroupBox();
            this.tb14443A_data = new System.Windows.Forms.TextBox();
            this.lb14443A_Data = new System.Windows.Forms.Label();
            this.cob14443A_block_num = new System.Windows.Forms.ComboBox();
            this.lb14443A_blocknum = new System.Windows.Forms.Label();
            this.btn14443A_write = new System.Windows.Forms.Button();
            this.btn14443A_read = new System.Windows.Forms.Button();
            this.tb14443A_key = new System.Windows.Forms.TextBox();
            this.lb14443A_key = new System.Windows.Forms.Label();
            this.cob14443A_mode_wr = new System.Windows.Forms.ComboBox();
            this.lb14443A_mode_wr = new System.Windows.Forms.Label();
            this.cob14443A_block_address = new System.Windows.Forms.ComboBox();
            this.lb14443_block_add = new System.Windows.Forms.Label();
            this.gb14443A_basiccmd = new System.Windows.Forms.GroupBox();
            this.gb14443A_select = new System.Windows.Forms.GroupBox();
            this.tb14443A_uid = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.btn14443A_Select = new System.Windows.Forms.Button();
            this.gb14443A_getsn = new System.Windows.Forms.GroupBox();
            this.cob14443A_halt = new System.Windows.Forms.ComboBox();
            this.lb14443A_halt = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.cob14443A_mode_get = new System.Windows.Forms.ComboBox();
            this.lb14443A_mode_get = new System.Windows.Forms.Label();
            this.btn14443A_halt = new System.Windows.Forms.Button();
            this.btn14443A_anticoll = new System.Windows.Forms.Button();
            this.btn14443A_inventory = new System.Windows.Forms.Button();
            this.cob14443A_mode = new System.Windows.Forms.ComboBox();
            this.lb14443A_mode = new System.Windows.Forms.Label();
            this.btnClear14443A = new System.Windows.Forms.Button();
            this.gb14443A_prompt = new System.Windows.Forms.GroupBox();
            this.tb14443A_message = new System.Windows.Forms.TextBox();
            this.rbMifare = new System.Windows.Forms.RadioButton();
            this.rbUltralight = new System.Windows.Forms.RadioButton();
            this.tabCtrlDemo.SuspendLayout();
            this.tp_setparam.SuspendLayout();
            this.gb_setparam_buzzer.SuspendLayout();
            this.gb_setparam_led.SuspendLayout();
            this.gb_setparam_bm.SuspendLayout();
            this.gb_setparam_setaddress.SuspendLayout();
            this.gb_setparam_pm.SuspendLayout();
            this.btn14443_get.SuspendLayout();
            this.gb14443A_cmd.SuspendLayout();
            this.gb14443A_ep.SuspendLayout();
            this.gb14443A_wr.SuspendLayout();
            this.gb14443A_basiccmd.SuspendLayout();
            this.gb14443A_select.SuspendLayout();
            this.gb14443A_getsn.SuspendLayout();
            this.gb14443A_prompt.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabCtrlDemo
            // 
            this.tabCtrlDemo.Controls.Add(this.tp_setparam);
            this.tabCtrlDemo.Controls.Add(this.btn14443_get);
            this.tabCtrlDemo.Location = new System.Drawing.Point(1, 12);
            this.tabCtrlDemo.Name = "tabCtrlDemo";
            this.tabCtrlDemo.SelectedIndex = 0;
            this.tabCtrlDemo.Size = new System.Drawing.Size(860, 537);
            this.tabCtrlDemo.TabIndex = 0;
            // 
            // tp_setparam
            // 
            this.tp_setparam.Controls.Add(this.gb_setparam_buzzer);
            this.tp_setparam.Controls.Add(this.gb_setparam_led);
            this.tp_setparam.Controls.Add(this.gb_setparam_bm);
            this.tp_setparam.Controls.Add(this.btn_setparam_clear);
            this.tp_setparam.Controls.Add(this.gb_setparam_pm);
            this.tp_setparam.Location = new System.Drawing.Point(4, 22);
            this.tp_setparam.Name = "tp_setparam";
            this.tp_setparam.Padding = new System.Windows.Forms.Padding(3);
            this.tp_setparam.Size = new System.Drawing.Size(852, 511);
            this.tp_setparam.TabIndex = 3;
            this.tp_setparam.Text = "Set Parameter";
            this.tp_setparam.UseVisualStyleBackColor = true;
            // 
            // gb_setparam_buzzer
            // 
            this.gb_setparam_buzzer.Controls.Add(this.btn_sp_buzzer_set);
            this.gb_setparam_buzzer.Controls.Add(this.tb_sp_buzzer_num);
            this.gb_setparam_buzzer.Controls.Add(this.lb_sp_buzzer_time);
            this.gb_setparam_buzzer.Controls.Add(this.tb_sp_buzzer_time);
            this.gb_setparam_buzzer.Controls.Add(this.lb_sp_buzzer_num);
            this.gb_setparam_buzzer.Location = new System.Drawing.Point(339, 183);
            this.gb_setparam_buzzer.Name = "gb_setparam_buzzer";
            this.gb_setparam_buzzer.Size = new System.Drawing.Size(320, 93);
            this.gb_setparam_buzzer.TabIndex = 3;
            this.gb_setparam_buzzer.TabStop = false;
            this.gb_setparam_buzzer.Text = "Set Buzzer";
            // 
            // btn_sp_buzzer_set
            // 
            this.btn_sp_buzzer_set.Location = new System.Drawing.Point(234, 39);
            this.btn_sp_buzzer_set.Name = "btn_sp_buzzer_set";
            this.btn_sp_buzzer_set.Size = new System.Drawing.Size(75, 23);
            this.btn_sp_buzzer_set.TabIndex = 5;
            this.btn_sp_buzzer_set.Text = "Set";
            this.btn_sp_buzzer_set.UseVisualStyleBackColor = true;
            this.btn_sp_buzzer_set.Click += new System.EventHandler(this.btn_sp_buzzer_set_Click);
            // 
            // tb_sp_buzzer_num
            // 
            this.tb_sp_buzzer_num.Location = new System.Drawing.Point(71, 58);
            this.tb_sp_buzzer_num.Name = "tb_sp_buzzer_num";
            this.tb_sp_buzzer_num.Size = new System.Drawing.Size(95, 21);
            this.tb_sp_buzzer_num.TabIndex = 3;
            // 
            // lb_sp_buzzer_time
            // 
            this.lb_sp_buzzer_time.AutoSize = true;
            this.lb_sp_buzzer_time.Location = new System.Drawing.Point(27, 29);
            this.lb_sp_buzzer_time.Name = "lb_sp_buzzer_time";
            this.lb_sp_buzzer_time.Size = new System.Drawing.Size(35, 12);
            this.lb_sp_buzzer_time.TabIndex = 0;
            this.lb_sp_buzzer_time.Text = "Time:";
            // 
            // tb_sp_buzzer_time
            // 
            this.tb_sp_buzzer_time.Location = new System.Drawing.Point(72, 27);
            this.tb_sp_buzzer_time.Name = "tb_sp_buzzer_time";
            this.tb_sp_buzzer_time.Size = new System.Drawing.Size(95, 21);
            this.tb_sp_buzzer_time.TabIndex = 2;
            // 
            // lb_sp_buzzer_num
            // 
            this.lb_sp_buzzer_num.AutoSize = true;
            this.lb_sp_buzzer_num.Location = new System.Drawing.Point(18, 63);
            this.lb_sp_buzzer_num.Name = "lb_sp_buzzer_num";
            this.lb_sp_buzzer_num.Size = new System.Drawing.Size(47, 12);
            this.lb_sp_buzzer_num.TabIndex = 1;
            this.lb_sp_buzzer_num.Text = "Number:";
            // 
            // gb_setparam_led
            // 
            this.gb_setparam_led.Controls.Add(this.btn_sp_led_set);
            this.gb_setparam_led.Controls.Add(this.tb_sp_led_num);
            this.gb_setparam_led.Controls.Add(this.tb_sp_led_time);
            this.gb_setparam_led.Controls.Add(this.label35);
            this.gb_setparam_led.Controls.Add(this.lb_sp_led_time);
            this.gb_setparam_led.Location = new System.Drawing.Point(7, 183);
            this.gb_setparam_led.Name = "gb_setparam_led";
            this.gb_setparam_led.Size = new System.Drawing.Size(326, 93);
            this.gb_setparam_led.TabIndex = 3;
            this.gb_setparam_led.TabStop = false;
            this.gb_setparam_led.Text = "Set LED";
            // 
            // btn_sp_led_set
            // 
            this.btn_sp_led_set.Location = new System.Drawing.Point(240, 39);
            this.btn_sp_led_set.Name = "btn_sp_led_set";
            this.btn_sp_led_set.Size = new System.Drawing.Size(75, 23);
            this.btn_sp_led_set.TabIndex = 5;
            this.btn_sp_led_set.Text = "Set";
            this.btn_sp_led_set.UseVisualStyleBackColor = true;
            this.btn_sp_led_set.Click += new System.EventHandler(this.btn_sp_led_set_Click);
            // 
            // tb_sp_led_num
            // 
            this.tb_sp_led_num.Location = new System.Drawing.Point(67, 58);
            this.tb_sp_led_num.Name = "tb_sp_led_num";
            this.tb_sp_led_num.Size = new System.Drawing.Size(95, 21);
            this.tb_sp_led_num.TabIndex = 3;
            // 
            // tb_sp_led_time
            // 
            this.tb_sp_led_time.Location = new System.Drawing.Point(68, 27);
            this.tb_sp_led_time.Name = "tb_sp_led_time";
            this.tb_sp_led_time.Size = new System.Drawing.Size(95, 21);
            this.tb_sp_led_time.TabIndex = 2;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(14, 63);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(47, 12);
            this.label35.TabIndex = 1;
            this.label35.Text = "Number:";
            // 
            // lb_sp_led_time
            // 
            this.lb_sp_led_time.AutoSize = true;
            this.lb_sp_led_time.Location = new System.Drawing.Point(23, 29);
            this.lb_sp_led_time.Name = "lb_sp_led_time";
            this.lb_sp_led_time.Size = new System.Drawing.Size(35, 12);
            this.lb_sp_led_time.TabIndex = 0;
            this.lb_sp_led_time.Text = "Time:";
            // 
            // gb_setparam_bm
            // 
            this.gb_setparam_bm.Controls.Add(this.gb_setparam_setaddress);
            this.gb_setparam_bm.Controls.Add(this.btn_setparam_read);
            this.gb_setparam_bm.Controls.Add(this.btn_sp_close);
            this.gb_setparam_bm.Controls.Add(this.btn_sp_open);
            this.gb_setparam_bm.Location = new System.Drawing.Point(7, 16);
            this.gb_setparam_bm.Name = "gb_setparam_bm";
            this.gb_setparam_bm.Size = new System.Drawing.Size(652, 161);
            this.gb_setparam_bm.TabIndex = 2;
            this.gb_setparam_bm.TabStop = false;
            this.gb_setparam_bm.Text = "Basic Command";
            // 
            // gb_setparam_setaddress
            // 
            this.gb_setparam_setaddress.Controls.Add(this.btn_setparam_setaddress);
            this.gb_setparam_setaddress.Controls.Add(this.cob_sp_address);
            this.gb_setparam_setaddress.Controls.Add(this.label34);
            this.gb_setparam_setaddress.Location = new System.Drawing.Point(8, 105);
            this.gb_setparam_setaddress.Name = "gb_setparam_setaddress";
            this.gb_setparam_setaddress.Size = new System.Drawing.Size(638, 48);
            this.gb_setparam_setaddress.TabIndex = 4;
            this.gb_setparam_setaddress.TabStop = false;
            this.gb_setparam_setaddress.Text = "Set Address";
            // 
            // btn_setparam_setaddress
            // 
            this.btn_setparam_setaddress.Location = new System.Drawing.Point(557, 16);
            this.btn_setparam_setaddress.Name = "btn_setparam_setaddress";
            this.btn_setparam_setaddress.Size = new System.Drawing.Size(75, 23);
            this.btn_setparam_setaddress.TabIndex = 5;
            this.btn_setparam_setaddress.Text = "Set";
            this.btn_setparam_setaddress.UseVisualStyleBackColor = true;
            this.btn_setparam_setaddress.Click += new System.EventHandler(this.btn_setparam_setaddress_Click);
            // 
            // cob_sp_address
            // 
            this.cob_sp_address.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cob_sp_address.FormattingEnabled = true;
            this.cob_sp_address.Location = new System.Drawing.Point(90, 19);
            this.cob_sp_address.Name = "cob_sp_address";
            this.cob_sp_address.Size = new System.Drawing.Size(94, 20);
            this.cob_sp_address.TabIndex = 4;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(6, 22);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(77, 12);
            this.label34.TabIndex = 3;
            this.label34.Text = "New address:";
            // 
            // btn_setparam_read
            // 
            this.btn_setparam_read.Location = new System.Drawing.Point(565, 77);
            this.btn_setparam_read.Name = "btn_setparam_read";
            this.btn_setparam_read.Size = new System.Drawing.Size(75, 23);
            this.btn_setparam_read.TabIndex = 2;
            this.btn_setparam_read.Text = "Read";
            this.btn_setparam_read.UseVisualStyleBackColor = true;
            this.btn_setparam_read.Click += new System.EventHandler(this.btn_setparam_read_Click);
            // 
            // btn_sp_close
            // 
            this.btn_sp_close.Enabled = false;
            this.btn_sp_close.Location = new System.Drawing.Point(565, 48);
            this.btn_sp_close.Name = "btn_sp_close";
            this.btn_sp_close.Size = new System.Drawing.Size(75, 23);
            this.btn_sp_close.TabIndex = 1;
            this.btn_sp_close.Text = "Close";
            this.btn_sp_close.UseVisualStyleBackColor = true;
            this.btn_sp_close.Click += new System.EventHandler(this.btn_setparam_close_Click);
            // 
            // btn_sp_open
            // 
            this.btn_sp_open.Location = new System.Drawing.Point(565, 19);
            this.btn_sp_open.Name = "btn_sp_open";
            this.btn_sp_open.Size = new System.Drawing.Size(75, 23);
            this.btn_sp_open.TabIndex = 0;
            this.btn_sp_open.Text = "Open";
            this.btn_sp_open.UseVisualStyleBackColor = true;
            this.btn_sp_open.Click += new System.EventHandler(this.btn_setparam_open_Click);
            // 
            // btn_setparam_clear
            // 
            this.btn_setparam_clear.Location = new System.Drawing.Point(586, 428);
            this.btn_setparam_clear.Name = "btn_setparam_clear";
            this.btn_setparam_clear.Size = new System.Drawing.Size(75, 23);
            this.btn_setparam_clear.TabIndex = 1;
            this.btn_setparam_clear.Text = "Clear";
            this.btn_setparam_clear.UseVisualStyleBackColor = true;
            this.btn_setparam_clear.Click += new System.EventHandler(this.btn_setparam_clear_Click);
            // 
            // gb_setparam_pm
            // 
            this.gb_setparam_pm.Controls.Add(this.tb_sp_message);
            this.gb_setparam_pm.Location = new System.Drawing.Point(665, 16);
            this.gb_setparam_pm.Name = "gb_setparam_pm";
            this.gb_setparam_pm.Size = new System.Drawing.Size(185, 440);
            this.gb_setparam_pm.TabIndex = 0;
            this.gb_setparam_pm.TabStop = false;
            this.gb_setparam_pm.Text = "Prompt Message";
            // 
            // tb_sp_message
            // 
            this.tb_sp_message.BackColor = System.Drawing.SystemColors.Control;
            this.tb_sp_message.Location = new System.Drawing.Point(0, 21);
            this.tb_sp_message.Multiline = true;
            this.tb_sp_message.Name = "tb_sp_message";
            this.tb_sp_message.ReadOnly = true;
            this.tb_sp_message.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tb_sp_message.Size = new System.Drawing.Size(185, 418);
            this.tb_sp_message.TabIndex = 0;
            this.tb_sp_message.TextChanged += new System.EventHandler(this.tb_sp_message_TextChanged);
            // 
            // btn14443_get
            // 
            this.btn14443_get.Controls.Add(this.gb14443A_cmd);
            this.btn14443_get.Controls.Add(this.gb14443A_ep);
            this.btn14443_get.Controls.Add(this.gb14443A_wr);
            this.btn14443_get.Controls.Add(this.gb14443A_basiccmd);
            this.btn14443_get.Controls.Add(this.btnClear14443A);
            this.btn14443_get.Controls.Add(this.gb14443A_prompt);
            this.btn14443_get.Location = new System.Drawing.Point(4, 22);
            this.btn14443_get.Name = "btn14443_get";
            this.btn14443_get.Padding = new System.Windows.Forms.Padding(3);
            this.btn14443_get.Size = new System.Drawing.Size(852, 511);
            this.btn14443_get.TabIndex = 2;
            this.btn14443_get.Text = "ISO 14443 A Card";
            this.btn14443_get.UseVisualStyleBackColor = true;
            // 
            // gb14443A_cmd
            // 
            this.gb14443A_cmd.Controls.Add(this.btn14443A_send);
            this.gb14443A_cmd.Controls.Add(this.tb14443A_cmd);
            this.gb14443A_cmd.Controls.Add(this.label33);
            this.gb14443A_cmd.Controls.Add(this.cob14443A_crc);
            this.gb14443A_cmd.Controls.Add(this.lb14443A_crc);
            this.gb14443A_cmd.Controls.Add(this.tb14443A_length);
            this.gb14443A_cmd.Controls.Add(this.lb14443A_length);
            this.gb14443A_cmd.Location = new System.Drawing.Point(10, 433);
            this.gb14443A_cmd.Name = "gb14443A_cmd";
            this.gb14443A_cmd.Size = new System.Drawing.Size(648, 75);
            this.gb14443A_cmd.TabIndex = 8;
            this.gb14443A_cmd.TabStop = false;
            this.gb14443A_cmd.Text = "CMD";
            // 
            // btn14443A_send
            // 
            this.btn14443A_send.Location = new System.Drawing.Point(566, 15);
            this.btn14443A_send.Name = "btn14443A_send";
            this.btn14443A_send.Size = new System.Drawing.Size(75, 22);
            this.btn14443A_send.TabIndex = 6;
            this.btn14443A_send.Text = "Send";
            this.btn14443A_send.UseVisualStyleBackColor = true;
            this.btn14443A_send.Click += new System.EventHandler(this.btn14443A_send_Click);
            // 
            // tb14443A_cmd
            // 
            this.tb14443A_cmd.Location = new System.Drawing.Point(64, 46);
            this.tb14443A_cmd.Name = "tb14443A_cmd";
            this.tb14443A_cmd.Size = new System.Drawing.Size(414, 21);
            this.tb14443A_cmd.TabIndex = 5;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(24, 49);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(29, 12);
            this.label33.TabIndex = 4;
            this.label33.Text = "CMD:";
            // 
            // cob14443A_crc
            // 
            this.cob14443A_crc.FormattingEnabled = true;
            this.cob14443A_crc.Location = new System.Drawing.Point(246, 17);
            this.cob14443A_crc.Name = "cob14443A_crc";
            this.cob14443A_crc.Size = new System.Drawing.Size(70, 20);
            this.cob14443A_crc.TabIndex = 3;
            // 
            // lb14443A_crc
            // 
            this.lb14443A_crc.AutoSize = true;
            this.lb14443A_crc.Location = new System.Drawing.Point(204, 22);
            this.lb14443A_crc.Name = "lb14443A_crc";
            this.lb14443A_crc.Size = new System.Drawing.Size(29, 12);
            this.lb14443A_crc.TabIndex = 2;
            this.lb14443A_crc.Text = "CRC:";
            // 
            // tb14443A_length
            // 
            this.tb14443A_length.Location = new System.Drawing.Point(64, 17);
            this.tb14443A_length.Name = "tb14443A_length";
            this.tb14443A_length.Size = new System.Drawing.Size(72, 21);
            this.tb14443A_length.TabIndex = 1;
            // 
            // lb14443A_length
            // 
            this.lb14443A_length.AutoSize = true;
            this.lb14443A_length.Location = new System.Drawing.Point(11, 22);
            this.lb14443A_length.Name = "lb14443A_length";
            this.lb14443A_length.Size = new System.Drawing.Size(47, 12);
            this.lb14443A_length.TabIndex = 0;
            this.lb14443A_length.Text = "Length:";
            // 
            // gb14443A_ep
            // 
            this.gb14443A_ep.Controls.Add(this.btn14443A_initial);
            this.gb14443A_ep.Controls.Add(this.btn14443A_decrement);
            this.gb14443A_ep.Controls.Add(this.btn14443A_increment);
            this.gb14443A_ep.Controls.Add(this.tb14443A_key_ep);
            this.gb14443A_ep.Controls.Add(this.lb14443A_key_ep);
            this.gb14443A_ep.Controls.Add(this.tb14443A_value);
            this.gb14443A_ep.Controls.Add(this.label32);
            this.gb14443A_ep.Controls.Add(this.cob14443A_mode_ep);
            this.gb14443A_ep.Controls.Add(this.lb14443A_mode_ep);
            this.gb14443A_ep.Controls.Add(this.cob14443A_sector);
            this.gb14443A_ep.Controls.Add(this.lb14443A_sector);
            this.gb14443A_ep.Location = new System.Drawing.Point(10, 350);
            this.gb14443A_ep.Name = "gb14443A_ep";
            this.gb14443A_ep.Size = new System.Drawing.Size(652, 77);
            this.gb14443A_ep.TabIndex = 7;
            this.gb14443A_ep.TabStop = false;
            this.gb14443A_ep.Text = "Electonic Purse";
            // 
            // btn14443A_initial
            // 
            this.btn14443A_initial.Location = new System.Drawing.Point(482, 20);
            this.btn14443A_initial.Name = "btn14443A_initial";
            this.btn14443A_initial.Size = new System.Drawing.Size(75, 23);
            this.btn14443A_initial.TabIndex = 8;
            this.btn14443A_initial.Text = "Initial";
            this.btn14443A_initial.UseVisualStyleBackColor = true;
            this.btn14443A_initial.Click += new System.EventHandler(this.btn14443A_initial_Click);
            // 
            // btn14443A_decrement
            // 
            this.btn14443A_decrement.Location = new System.Drawing.Point(566, 46);
            this.btn14443A_decrement.Name = "btn14443A_decrement";
            this.btn14443A_decrement.Size = new System.Drawing.Size(75, 22);
            this.btn14443A_decrement.TabIndex = 8;
            this.btn14443A_decrement.Text = "Decrement";
            this.btn14443A_decrement.UseVisualStyleBackColor = true;
            this.btn14443A_decrement.Click += new System.EventHandler(this.btn14443A_decrement_Click);
            // 
            // btn14443A_increment
            // 
            this.btn14443A_increment.Location = new System.Drawing.Point(566, 20);
            this.btn14443A_increment.Name = "btn14443A_increment";
            this.btn14443A_increment.Size = new System.Drawing.Size(75, 22);
            this.btn14443A_increment.TabIndex = 8;
            this.btn14443A_increment.Text = "Increment";
            this.btn14443A_increment.UseVisualStyleBackColor = true;
            this.btn14443A_increment.Click += new System.EventHandler(this.btn14443A_increment_Click);
            // 
            // tb14443A_key_ep
            // 
            this.tb14443A_key_ep.Location = new System.Drawing.Point(245, 48);
            this.tb14443A_key_ep.Name = "tb14443A_key_ep";
            this.tb14443A_key_ep.Size = new System.Drawing.Size(163, 21);
            this.tb14443A_key_ep.TabIndex = 7;
            // 
            // lb14443A_key_ep
            // 
            this.lb14443A_key_ep.Location = new System.Drawing.Point(185, 46);
            this.lb14443A_key_ep.Name = "lb14443A_key_ep";
            this.lb14443A_key_ep.Size = new System.Drawing.Size(47, 20);
            this.lb14443A_key_ep.TabIndex = 6;
            this.lb14443A_key_ep.Text = "Key:";
            this.lb14443A_key_ep.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tb14443A_value
            // 
            this.tb14443A_value.Location = new System.Drawing.Point(65, 46);
            this.tb14443A_value.Name = "tb14443A_value";
            this.tb14443A_value.Size = new System.Drawing.Size(102, 21);
            this.tb14443A_value.TabIndex = 5;
            // 
            // label32
            // 
            this.label32.Location = new System.Drawing.Point(12, 52);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(47, 15);
            this.label32.TabIndex = 4;
            this.label32.Text = "Value:";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cob14443A_mode_ep
            // 
            this.cob14443A_mode_ep.FormattingEnabled = true;
            this.cob14443A_mode_ep.Location = new System.Drawing.Point(245, 20);
            this.cob14443A_mode_ep.Name = "cob14443A_mode_ep";
            this.cob14443A_mode_ep.Size = new System.Drawing.Size(100, 20);
            this.cob14443A_mode_ep.TabIndex = 3;
            // 
            // lb14443A_mode_ep
            // 
            this.lb14443A_mode_ep.AutoSize = true;
            this.lb14443A_mode_ep.Location = new System.Drawing.Point(204, 25);
            this.lb14443A_mode_ep.Name = "lb14443A_mode_ep";
            this.lb14443A_mode_ep.Size = new System.Drawing.Size(35, 12);
            this.lb14443A_mode_ep.TabIndex = 2;
            this.lb14443A_mode_ep.Text = "Mode:";
            // 
            // cob14443A_sector
            // 
            this.cob14443A_sector.FormattingEnabled = true;
            this.cob14443A_sector.Location = new System.Drawing.Point(65, 20);
            this.cob14443A_sector.Name = "cob14443A_sector";
            this.cob14443A_sector.Size = new System.Drawing.Size(72, 20);
            this.cob14443A_sector.TabIndex = 1;
            // 
            // lb14443A_sector
            // 
            this.lb14443A_sector.AutoSize = true;
            this.lb14443A_sector.Location = new System.Drawing.Point(12, 24);
            this.lb14443A_sector.Name = "lb14443A_sector";
            this.lb14443A_sector.Size = new System.Drawing.Size(47, 12);
            this.lb14443A_sector.TabIndex = 0;
            this.lb14443A_sector.Text = "Sector:";
            // 
            // gb14443A_wr
            // 
            this.gb14443A_wr.Controls.Add(this.rbUltralight);
            this.gb14443A_wr.Controls.Add(this.rbMifare);
            this.gb14443A_wr.Controls.Add(this.tb14443A_data);
            this.gb14443A_wr.Controls.Add(this.lb14443A_Data);
            this.gb14443A_wr.Controls.Add(this.cob14443A_block_num);
            this.gb14443A_wr.Controls.Add(this.lb14443A_blocknum);
            this.gb14443A_wr.Controls.Add(this.btn14443A_write);
            this.gb14443A_wr.Controls.Add(this.btn14443A_read);
            this.gb14443A_wr.Controls.Add(this.tb14443A_key);
            this.gb14443A_wr.Controls.Add(this.lb14443A_key);
            this.gb14443A_wr.Controls.Add(this.cob14443A_mode_wr);
            this.gb14443A_wr.Controls.Add(this.lb14443A_mode_wr);
            this.gb14443A_wr.Controls.Add(this.cob14443A_block_address);
            this.gb14443A_wr.Controls.Add(this.lb14443_block_add);
            this.gb14443A_wr.Location = new System.Drawing.Point(10, 233);
            this.gb14443A_wr.Name = "gb14443A_wr";
            this.gb14443A_wr.Size = new System.Drawing.Size(648, 111);
            this.gb14443A_wr.TabIndex = 6;
            this.gb14443A_wr.TabStop = false;
            this.gb14443A_wr.Text = "Write/Read";
            // 
            // tb14443A_data
            // 
            this.tb14443A_data.Location = new System.Drawing.Point(187, 83);
            this.tb14443A_data.Name = "tb14443A_data";
            this.tb14443A_data.Size = new System.Drawing.Size(370, 21);
            this.tb14443A_data.TabIndex = 10;
            // 
            // lb14443A_Data
            // 
            this.lb14443A_Data.AutoSize = true;
            this.lb14443A_Data.Location = new System.Drawing.Point(153, 85);
            this.lb14443A_Data.Name = "lb14443A_Data";
            this.lb14443A_Data.Size = new System.Drawing.Size(35, 12);
            this.lb14443A_Data.TabIndex = 9;
            this.lb14443A_Data.Text = "Data:";
            // 
            // cob14443A_block_num
            // 
            this.cob14443A_block_num.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cob14443A_block_num.DropDownWidth = 55;
            this.cob14443A_block_num.FormattingEnabled = true;
            this.cob14443A_block_num.Location = new System.Drawing.Point(92, 82);
            this.cob14443A_block_num.Name = "cob14443A_block_num";
            this.cob14443A_block_num.Size = new System.Drawing.Size(55, 20);
            this.cob14443A_block_num.TabIndex = 8;
            this.cob14443A_block_num.SelectedIndexChanged += new System.EventHandler(this.cob14443A_block_num_SelectedIndexChanged);
            // 
            // lb14443A_blocknum
            // 
            this.lb14443A_blocknum.Location = new System.Drawing.Point(6, 81);
            this.lb14443A_blocknum.Name = "lb14443A_blocknum";
            this.lb14443A_blocknum.Size = new System.Drawing.Size(86, 21);
            this.lb14443A_blocknum.TabIndex = 7;
            this.lb14443A_blocknum.Text = "Block Number:";
            this.lb14443A_blocknum.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btn14443A_write
            // 
            this.btn14443A_write.Location = new System.Drawing.Point(566, 83);
            this.btn14443A_write.Name = "btn14443A_write";
            this.btn14443A_write.Size = new System.Drawing.Size(75, 22);
            this.btn14443A_write.TabIndex = 6;
            this.btn14443A_write.Text = "Write";
            this.btn14443A_write.UseVisualStyleBackColor = true;
            this.btn14443A_write.Click += new System.EventHandler(this.btn14443A_write_Click);
            // 
            // btn14443A_read
            // 
            this.btn14443A_read.Location = new System.Drawing.Point(566, 54);
            this.btn14443A_read.Name = "btn14443A_read";
            this.btn14443A_read.Size = new System.Drawing.Size(75, 22);
            this.btn14443A_read.TabIndex = 6;
            this.btn14443A_read.Text = "Read";
            this.btn14443A_read.UseVisualStyleBackColor = true;
            this.btn14443A_read.Click += new System.EventHandler(this.btn14443A_read_Click);
            // 
            // tb14443A_key
            // 
            this.tb14443A_key.Location = new System.Drawing.Point(354, 56);
            this.tb14443A_key.Name = "tb14443A_key";
            this.tb14443A_key.Size = new System.Drawing.Size(203, 21);
            this.tb14443A_key.TabIndex = 5;
            // 
            // lb14443A_key
            // 
            this.lb14443A_key.AutoSize = true;
            this.lb14443A_key.Location = new System.Drawing.Point(319, 59);
            this.lb14443A_key.Name = "lb14443A_key";
            this.lb14443A_key.Size = new System.Drawing.Size(29, 12);
            this.lb14443A_key.TabIndex = 4;
            this.lb14443A_key.Text = "Key:";
            // 
            // cob14443A_mode_wr
            // 
            this.cob14443A_mode_wr.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cob14443A_mode_wr.DropDownWidth = 72;
            this.cob14443A_mode_wr.FormattingEnabled = true;
            this.cob14443A_mode_wr.Location = new System.Drawing.Point(187, 54);
            this.cob14443A_mode_wr.Name = "cob14443A_mode_wr";
            this.cob14443A_mode_wr.Size = new System.Drawing.Size(107, 20);
            this.cob14443A_mode_wr.TabIndex = 3;
            // 
            // lb14443A_mode_wr
            // 
            this.lb14443A_mode_wr.Location = new System.Drawing.Point(153, 59);
            this.lb14443A_mode_wr.Name = "lb14443A_mode_wr";
            this.lb14443A_mode_wr.Size = new System.Drawing.Size(35, 12);
            this.lb14443A_mode_wr.TabIndex = 2;
            this.lb14443A_mode_wr.Text = "Mode:";
            // 
            // cob14443A_block_address
            // 
            this.cob14443A_block_address.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cob14443A_block_address.FormattingEnabled = true;
            this.cob14443A_block_address.Location = new System.Drawing.Point(92, 55);
            this.cob14443A_block_address.Name = "cob14443A_block_address";
            this.cob14443A_block_address.Size = new System.Drawing.Size(55, 20);
            this.cob14443A_block_address.TabIndex = 1;
            // 
            // lb14443_block_add
            // 
            this.lb14443_block_add.AutoSize = true;
            this.lb14443_block_add.Location = new System.Drawing.Point(6, 58);
            this.lb14443_block_add.Name = "lb14443_block_add";
            this.lb14443_block_add.Size = new System.Drawing.Size(89, 12);
            this.lb14443_block_add.TabIndex = 0;
            this.lb14443_block_add.Text = "Block Address:";
            // 
            // gb14443A_basiccmd
            // 
            this.gb14443A_basiccmd.Controls.Add(this.gb14443A_select);
            this.gb14443A_basiccmd.Controls.Add(this.gb14443A_getsn);
            this.gb14443A_basiccmd.Controls.Add(this.btn14443A_halt);
            this.gb14443A_basiccmd.Controls.Add(this.btn14443A_anticoll);
            this.gb14443A_basiccmd.Controls.Add(this.btn14443A_inventory);
            this.gb14443A_basiccmd.Controls.Add(this.cob14443A_mode);
            this.gb14443A_basiccmd.Controls.Add(this.lb14443A_mode);
            this.gb14443A_basiccmd.Location = new System.Drawing.Point(10, 15);
            this.gb14443A_basiccmd.Name = "gb14443A_basiccmd";
            this.gb14443A_basiccmd.Size = new System.Drawing.Size(648, 212);
            this.gb14443A_basiccmd.TabIndex = 5;
            this.gb14443A_basiccmd.TabStop = false;
            this.gb14443A_basiccmd.Text = "Basic Command";
            // 
            // gb14443A_select
            // 
            this.gb14443A_select.Controls.Add(this.tb14443A_uid);
            this.gb14443A_select.Controls.Add(this.label31);
            this.gb14443A_select.Controls.Add(this.btn14443A_Select);
            this.gb14443A_select.Location = new System.Drawing.Point(6, 71);
            this.gb14443A_select.Name = "gb14443A_select";
            this.gb14443A_select.Size = new System.Drawing.Size(636, 47);
            this.gb14443A_select.TabIndex = 11;
            this.gb14443A_select.TabStop = false;
            this.gb14443A_select.Text = "Select";
            // 
            // tb14443A_uid
            // 
            this.tb14443A_uid.Location = new System.Drawing.Point(59, 16);
            this.tb14443A_uid.Name = "tb14443A_uid";
            this.tb14443A_uid.ReadOnly = true;
            this.tb14443A_uid.Size = new System.Drawing.Size(155, 21);
            this.tb14443A_uid.TabIndex = 7;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(18, 19);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(29, 12);
            this.label31.TabIndex = 6;
            this.label31.Text = "UID:";
            // 
            // btn14443A_Select
            // 
            this.btn14443A_Select.Location = new System.Drawing.Point(560, 14);
            this.btn14443A_Select.Name = "btn14443A_Select";
            this.btn14443A_Select.Size = new System.Drawing.Size(75, 22);
            this.btn14443A_Select.TabIndex = 8;
            this.btn14443A_Select.Text = "Select";
            this.btn14443A_Select.UseVisualStyleBackColor = true;
            this.btn14443A_Select.Click += new System.EventHandler(this.btn14443A_Select_Click);
            // 
            // gb14443A_getsn
            // 
            this.gb14443A_getsn.Controls.Add(this.cob14443A_halt);
            this.gb14443A_getsn.Controls.Add(this.lb14443A_halt);
            this.gb14443A_getsn.Controls.Add(this.button1);
            this.gb14443A_getsn.Controls.Add(this.cob14443A_mode_get);
            this.gb14443A_getsn.Controls.Add(this.lb14443A_mode_get);
            this.gb14443A_getsn.Location = new System.Drawing.Point(6, 151);
            this.gb14443A_getsn.Name = "gb14443A_getsn";
            this.gb14443A_getsn.Size = new System.Drawing.Size(636, 49);
            this.gb14443A_getsn.TabIndex = 10;
            this.gb14443A_getsn.TabStop = false;
            this.gb14443A_getsn.Text = "Get Serial Number";
            // 
            // cob14443A_halt
            // 
            this.cob14443A_halt.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cob14443A_halt.FormattingEnabled = true;
            this.cob14443A_halt.Location = new System.Drawing.Point(220, 21);
            this.cob14443A_halt.Name = "cob14443A_halt";
            this.cob14443A_halt.Size = new System.Drawing.Size(74, 20);
            this.cob14443A_halt.TabIndex = 4;
            // 
            // lb14443A_halt
            // 
            this.lb14443A_halt.AutoSize = true;
            this.lb14443A_halt.Location = new System.Drawing.Point(179, 23);
            this.lb14443A_halt.Name = "lb14443A_halt";
            this.lb14443A_halt.Size = new System.Drawing.Size(35, 12);
            this.lb14443A_halt.TabIndex = 3;
            this.lb14443A_halt.Text = "Halt:";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(560, 19);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 22);
            this.button1.TabIndex = 2;
            this.button1.Text = "Get";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // cob14443A_mode_get
            // 
            this.cob14443A_mode_get.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cob14443A_mode_get.FormattingEnabled = true;
            this.cob14443A_mode_get.Location = new System.Drawing.Point(59, 20);
            this.cob14443A_mode_get.Name = "cob14443A_mode_get";
            this.cob14443A_mode_get.Size = new System.Drawing.Size(72, 20);
            this.cob14443A_mode_get.TabIndex = 1;
            // 
            // lb14443A_mode_get
            // 
            this.lb14443A_mode_get.AutoSize = true;
            this.lb14443A_mode_get.Location = new System.Drawing.Point(18, 24);
            this.lb14443A_mode_get.Name = "lb14443A_mode_get";
            this.lb14443A_mode_get.Size = new System.Drawing.Size(35, 12);
            this.lb14443A_mode_get.TabIndex = 0;
            this.lb14443A_mode_get.Text = "Mode:";
            // 
            // btn14443A_halt
            // 
            this.btn14443A_halt.Location = new System.Drawing.Point(566, 124);
            this.btn14443A_halt.Name = "btn14443A_halt";
            this.btn14443A_halt.Size = new System.Drawing.Size(75, 22);
            this.btn14443A_halt.TabIndex = 9;
            this.btn14443A_halt.Text = "Halt";
            this.btn14443A_halt.UseVisualStyleBackColor = true;
            this.btn14443A_halt.Click += new System.EventHandler(this.btn14443A_halt_Click);
            // 
            // btn14443A_anticoll
            // 
            this.btn14443A_anticoll.Location = new System.Drawing.Point(566, 47);
            this.btn14443A_anticoll.Name = "btn14443A_anticoll";
            this.btn14443A_anticoll.Size = new System.Drawing.Size(75, 22);
            this.btn14443A_anticoll.TabIndex = 5;
            this.btn14443A_anticoll.Text = "Anticoll";
            this.btn14443A_anticoll.UseVisualStyleBackColor = true;
            this.btn14443A_anticoll.Click += new System.EventHandler(this.btn14443A_anticoll_Click);
            // 
            // btn14443A_inventory
            // 
            this.btn14443A_inventory.Location = new System.Drawing.Point(566, 18);
            this.btn14443A_inventory.Name = "btn14443A_inventory";
            this.btn14443A_inventory.Size = new System.Drawing.Size(75, 22);
            this.btn14443A_inventory.TabIndex = 4;
            this.btn14443A_inventory.Text = "Inventory";
            this.btn14443A_inventory.UseVisualStyleBackColor = true;
            this.btn14443A_inventory.Click += new System.EventHandler(this.btn14443A_inventory_Click);
            // 
            // cob14443A_mode
            // 
            this.cob14443A_mode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cob14443A_mode.FormattingEnabled = true;
            this.cob14443A_mode.Location = new System.Drawing.Point(65, 20);
            this.cob14443A_mode.Name = "cob14443A_mode";
            this.cob14443A_mode.Size = new System.Drawing.Size(72, 20);
            this.cob14443A_mode.TabIndex = 3;
            // 
            // lb14443A_mode
            // 
            this.lb14443A_mode.AutoSize = true;
            this.lb14443A_mode.Location = new System.Drawing.Point(24, 23);
            this.lb14443A_mode.Name = "lb14443A_mode";
            this.lb14443A_mode.Size = new System.Drawing.Size(35, 12);
            this.lb14443A_mode.TabIndex = 2;
            this.lb14443A_mode.Text = "Mode:";
            this.lb14443A_mode.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnClear14443A
            // 
            this.btnClear14443A.Location = new System.Drawing.Point(756, 463);
            this.btnClear14443A.Name = "btnClear14443A";
            this.btnClear14443A.Size = new System.Drawing.Size(75, 23);
            this.btnClear14443A.TabIndex = 1;
            this.btnClear14443A.Text = "Clear";
            this.btnClear14443A.UseVisualStyleBackColor = true;
            this.btnClear14443A.Click += new System.EventHandler(this.btnClear14443A_Click);
            // 
            // gb14443A_prompt
            // 
            this.gb14443A_prompt.Controls.Add(this.tb14443A_message);
            this.gb14443A_prompt.Location = new System.Drawing.Point(664, 15);
            this.gb14443A_prompt.Name = "gb14443A_prompt";
            this.gb14443A_prompt.Size = new System.Drawing.Size(184, 441);
            this.gb14443A_prompt.TabIndex = 0;
            this.gb14443A_prompt.TabStop = false;
            this.gb14443A_prompt.Text = "Prompt Message";
            // 
            // tb14443A_message
            // 
            this.tb14443A_message.BackColor = System.Drawing.SystemColors.Control;
            this.tb14443A_message.Location = new System.Drawing.Point(4, 20);
            this.tb14443A_message.Multiline = true;
            this.tb14443A_message.Name = "tb14443A_message";
            this.tb14443A_message.ReadOnly = true;
            this.tb14443A_message.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tb14443A_message.Size = new System.Drawing.Size(184, 421);
            this.tb14443A_message.TabIndex = 0;
            this.tb14443A_message.TextChanged += new System.EventHandler(this.tb14444A_message_TextChanged);
            // 
            // rbMifare
            // 
            this.rbMifare.AutoSize = true;
            this.rbMifare.Location = new System.Drawing.Point(98, 27);
            this.rbMifare.Name = "rbMifare";
            this.rbMifare.Size = new System.Drawing.Size(89, 16);
            this.rbMifare.TabIndex = 11;
            this.rbMifare.TabStop = true;
            this.rbMifare.Text = "Mifare Card";
            this.rbMifare.UseVisualStyleBackColor = true;
            this.rbMifare.CheckedChanged += new System.EventHandler(this.rbMifare_CheckedChanged);
            // 
            // rbUltralight
            // 
            this.rbUltralight.AutoSize = true;
            this.rbUltralight.Location = new System.Drawing.Point(321, 27);
            this.rbUltralight.Name = "rbUltralight";
            this.rbUltralight.Size = new System.Drawing.Size(113, 16);
            this.rbUltralight.TabIndex = 11;
            this.rbUltralight.TabStop = true;
            this.rbUltralight.Text = "Ultralight Card";
            this.rbUltralight.UseVisualStyleBackColor = true;
            this.rbUltralight.CheckedChanged += new System.EventHandler(this.rbUltralight_CheckedChanged);
            // 
            // dlgDemo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(863, 545);
            this.Controls.Add(this.tabCtrlDemo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "dlgDemo";
            this.Text = "Demo";
            this.Load += new System.EventHandler(this.dlgDemo_Load);
            this.tabCtrlDemo.ResumeLayout(false);
            this.tp_setparam.ResumeLayout(false);
            this.gb_setparam_buzzer.ResumeLayout(false);
            this.gb_setparam_buzzer.PerformLayout();
            this.gb_setparam_led.ResumeLayout(false);
            this.gb_setparam_led.PerformLayout();
            this.gb_setparam_bm.ResumeLayout(false);
            this.gb_setparam_setaddress.ResumeLayout(false);
            this.gb_setparam_setaddress.PerformLayout();
            this.gb_setparam_pm.ResumeLayout(false);
            this.gb_setparam_pm.PerformLayout();
            this.btn14443_get.ResumeLayout(false);
            this.gb14443A_cmd.ResumeLayout(false);
            this.gb14443A_cmd.PerformLayout();
            this.gb14443A_ep.ResumeLayout(false);
            this.gb14443A_ep.PerformLayout();
            this.gb14443A_wr.ResumeLayout(false);
            this.gb14443A_wr.PerformLayout();
            this.gb14443A_basiccmd.ResumeLayout(false);
            this.gb14443A_basiccmd.PerformLayout();
            this.gb14443A_select.ResumeLayout(false);
            this.gb14443A_select.PerformLayout();
            this.gb14443A_getsn.ResumeLayout(false);
            this.gb14443A_getsn.PerformLayout();
            this.gb14443A_prompt.ResumeLayout(false);
            this.gb14443A_prompt.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabCtrlDemo;
        private System.Windows.Forms.TabPage btn14443_get;
        private System.Windows.Forms.GroupBox gb14443A_prompt;
        private System.Windows.Forms.TextBox tb14443A_message;
        private System.Windows.Forms.Button btnClear14443A;
        private System.Windows.Forms.GroupBox gb14443A_basiccmd;
        private System.Windows.Forms.Button btn14443A_inventory;
        private System.Windows.Forms.ComboBox cob14443A_mode;
        private System.Windows.Forms.Label lb14443A_mode;
        private System.Windows.Forms.Button btn14443A_anticoll;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Button btn14443A_Select;
        private System.Windows.Forms.TextBox tb14443A_uid;
        private System.Windows.Forms.GroupBox gb14443A_select;
        private System.Windows.Forms.GroupBox gb14443A_getsn;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox cob14443A_mode_get;
        private System.Windows.Forms.Label lb14443A_mode_get;
        private System.Windows.Forms.Button btn14443A_halt;
        private System.Windows.Forms.GroupBox gb14443A_wr;
        private System.Windows.Forms.Label lb14443A_key;
        private System.Windows.Forms.ComboBox cob14443A_mode_wr;
        private System.Windows.Forms.Label lb14443A_mode_wr;
        private System.Windows.Forms.ComboBox cob14443A_block_address;
        private System.Windows.Forms.Label lb14443_block_add;
        private System.Windows.Forms.TextBox tb14443A_key;
        private System.Windows.Forms.ComboBox cob14443A_block_num;
        private System.Windows.Forms.Label lb14443A_blocknum;
        private System.Windows.Forms.Button btn14443A_read;
        private System.Windows.Forms.TextBox tb14443A_data;
        private System.Windows.Forms.Label lb14443A_Data;
        private System.Windows.Forms.Button btn14443A_write;
        private System.Windows.Forms.GroupBox gb14443A_ep;
        private System.Windows.Forms.Label lb14443A_sector;
        private System.Windows.Forms.ComboBox cob14443A_sector;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.ComboBox cob14443A_mode_ep;
        private System.Windows.Forms.Label lb14443A_mode_ep;
        private System.Windows.Forms.Label lb14443A_key_ep;
        private System.Windows.Forms.TextBox tb14443A_value;
        private System.Windows.Forms.Button btn14443A_initial;
        private System.Windows.Forms.Button btn14443A_decrement;
        private System.Windows.Forms.Button btn14443A_increment;
        private System.Windows.Forms.TextBox tb14443A_key_ep;
        private System.Windows.Forms.GroupBox gb14443A_cmd;
        private System.Windows.Forms.Label lb14443A_length;
        private System.Windows.Forms.TextBox tb14443A_length;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.ComboBox cob14443A_crc;
        private System.Windows.Forms.Label lb14443A_crc;
        private System.Windows.Forms.TextBox tb14443A_cmd;
        private System.Windows.Forms.TabPage tp_setparam;
        private System.Windows.Forms.GroupBox gb_setparam_pm;
        private System.Windows.Forms.TextBox tb_sp_message;
        private System.Windows.Forms.Button btn_setparam_clear;
        private System.Windows.Forms.GroupBox gb_setparam_bm;
        private System.Windows.Forms.Button btn_sp_open;
        private System.Windows.Forms.Button btn_sp_close;
        private System.Windows.Forms.Button btn_setparam_read;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.GroupBox gb_setparam_setaddress;
        private System.Windows.Forms.ComboBox cob_sp_address;
        private System.Windows.Forms.Button btn_setparam_setaddress;
        private System.Windows.Forms.GroupBox gb_setparam_buzzer;
        private System.Windows.Forms.GroupBox gb_setparam_led;
        private System.Windows.Forms.Label lb_sp_led_time;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox tb_sp_led_num;
        private System.Windows.Forms.TextBox tb_sp_led_time;
        private System.Windows.Forms.Button btn_sp_led_set;
        private System.Windows.Forms.Button btn_sp_buzzer_set;
        private System.Windows.Forms.TextBox tb_sp_buzzer_num;
        private System.Windows.Forms.Label lb_sp_buzzer_time;
        private System.Windows.Forms.TextBox tb_sp_buzzer_time;
        private System.Windows.Forms.Label lb_sp_buzzer_num;
        private System.Windows.Forms.Button btn14443A_send;
        private System.Windows.Forms.Label lb14443A_halt;
        private System.Windows.Forms.ComboBox cob14443A_halt;
        private System.Windows.Forms.RadioButton rbMifare;
        private System.Windows.Forms.RadioButton rbUltralight;
    }
}

