﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Timers;


namespace Demo
{
    public partial class dlgDemo : Form
    {
        CReader reader = new CReader();

        public dlgDemo()
        {
            InitializeComponent();
        }

        //private System.Timers.Timer timerClock = new System.Timers.Timer();   

        private void dlgDemo_Load(object sender, EventArgs e)
        {
            int i;
            string strTmp;


            //////////////Set Parameter tab page////////////////////////
            //////组合框初始地址
            for (i = 0; i < 0xff + 1; i++)
            {
                strTmp = string.Format("{0:X2}", i);
                cob_sp_address.Items.Add(strTmp);
            }
            cob_sp_address.SelectedIndex = 0;
            ////设置LED 初始值
            tb_sp_led_time.Text = "0X18";
            tb_sp_led_num.Text = "0X0A";
            /////设置Buzzer初始值
            tb_sp_buzzer_time.Text = "0X18";
            tb_sp_buzzer_num.Text = "0X0A";

            /////////////////14443A tab page Start/////////////////////////
            ///////////////////////
            //////////////////////
            //////////////Inventory 的mode初始值
            cob14443A_mode.Items.Insert(0, "All");
            cob14443A_mode.Items.Insert(1, "Idle");
            //cob14443A_mode.SelectedItem = "Idle";
            cob14443A_mode.SelectedIndex = 1;

            ////////Get  mode的初始化
            cob14443A_mode_get.Items.Insert(0, "All");
            cob14443A_mode_get.Items.Insert(1, "Idle");
            cob14443A_mode_get.SelectedIndex = 1;
            ///////Halt 的初始化
            cob14443A_halt.Items.Add("None");
            cob14443A_halt.Items.Add("Halt");
            cob14443A_halt.SelectedIndex = 0;


            /////////Read block address 的初始化
            for (i = 0; i < 0xFF + 1; i++)
            {
                strTmp = string.Format("{0:X2}", i);
                cob14443A_block_address.Items.Insert(i, strTmp);
            }
            cob14443A_block_address.SelectedIndex = 0;

            rbMifare.Checked = true;
            rbUltralight.Checked = false;
            /////////Read/write mode 初始值
            cob14443A_mode_wr.Items.Insert(0, "Idle + Key A");
            cob14443A_mode_wr.Items.Insert(1, "All + Key A");
            cob14443A_mode_wr.Items.Insert(2, "Idle + Key B");
            cob14443A_mode_wr.Items.Insert(3, "All + Key B");
            cob14443A_mode_wr.SelectedIndex = 0;

            /////////read/write Key 初始值
            tb14443A_key.Text = "FF FF FF FF FF FF";

            /////////Read/Write number 初始值 
            for (i = 0; i < 0x04; i++)
            {
                strTmp = string.Format("{0:X2}", i + 1);
                cob14443A_block_num.Items.Insert(i, strTmp);
            }
            cob14443A_block_num.SelectedIndex = 0;

            /////////Read/Write data 初始值
            tb14443A_data.Text = "FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF";

            ////////EP sector初始化
            for (i = 0; i < 0x0F + 1; i++)
            {
                strTmp = string.Format("{0:X2}", i);
                cob14443A_sector.Items.Add(strTmp);
            }
            cob14443A_sector.SelectedIndex = 0;

            ///////EP mode初始化
            string[] mode = new string[] { "Idle + Key A", "All + Key A", "Idle + Key B", "All + Key B" };
            cob14443A_mode_ep.Items.AddRange(mode);
            cob14443A_mode_ep.SelectedIndex = 0;

            ///////EP value初始化
            tb14443A_value.Text = "01 00 00 00";

            //////EP key 初始化
            tb14443A_key_ep.Text = "FF FF FF FF FF FF";

            //////CMD Length初始化
            tb14443A_length.Text = "0D";

            /////CMD CRC初始化
            cob14443A_crc.Items.Insert(0, "None");
            cob14443A_crc.Items.Insert(1, "CRC");
            cob14443A_crc.SelectedIndex = 0;

            ///////CMD cmd初始化
            tb14443A_cmd.Text = "00 A4 04 0C 08 A0 00 00 03 41 00 00 01";


            ////////////////////////各种空间的初始状态//////////////////////


            ///////////////////////END///////////////////////////////////
            /////////////////14443A tab page End/////////////////////////
            //////////////////////////////////////////
        }

        private void btnClear14443A_Click(object sender, EventArgs e)
        {
            tb14443A_message.Text = " ";
        }

        private void btn14443A_inventory_Click(object sender, EventArgs e)
        {
            CheckForIllegalCrossThreadCalls = false;
            string strTmp = "";
            byte[] buf = new byte[256];
            byte mode = (byte)cob14443A_mode.SelectedIndex;////需要修改

            int ret = reader.HID_Request_14443A(mode, ref buf[0]);
            if (ret == 0)
            {
                for (int i = 0; i < 2; i++)
                {
                    strTmp += buf[i].ToString("X2");
                }

                tb14443A_message.Text += "\r\nType of card is " + strTmp;
                tb14443A_message.Text += "\r\n";
            }
            else if (ret == -1)
            {
                tb14443A_message.Text += "\r\nThe device is not opened !\r\n";
            }
            else
            {
                tb14443A_message.Text += CPublic.ShowError(ret, ref buf[0]);
            }

            CheckForIllegalCrossThreadCalls = true;
        }

        private void btn_setparam_clear_Click(object sender, EventArgs e)
        {
            tb_sp_message.Text = " ";
        }

        private void btn14443A_anticoll_Click(object sender, EventArgs e)
        {
            string strTmp = "";
            byte[] buf = new byte[16];
            byte flag = 2;

            int ret = reader.HID_Anticoll_14443A(ref flag, ref buf[0]);
            if (ret == 0)
            {
                if (flag == 0)
                {
                    tb14443A_message.Text += "\r\nThere is only one card !\r\n";
                }
                else if (flag == 1)
                {
                    tb14443A_message.Text += "\r\nThere are multiple cards !\r\n";
                }
                else if (flag == 2)
                {
                    tb14443A_message.Text += "\r\nMaybe the initial flag value is 2 !\r\n";
                }
                else
                {
                    tb14443A_message.Text += "\r\nUnknown reason !\r\n";
                }

                for (int i = 0; i < buf[0]; i++)
                {
                    strTmp += buf[i + 1].ToString("X2");
                }

                //if (String.IsNullOrEmpty(tb14443A_uid.Text))
                //{
                //    MessageBox.Show("null");
                //}
                //else
                //{
                //    MessageBox.Show("no null");
                //}

                tb14443A_uid.Text = strTmp;
                tb14443A_message.Text += "\r\nThe card' serial number is " + strTmp;
                tb14443A_message.Text += "\r\n";
            }
            else if (ret == -1)
            {
                tb14443A_message.Text += "\r\nThe device is not opened !\r\n";
            }
            else
            {
                tb14443A_message.Text += CPublic.ShowError(ret, ref buf[0]);
            }
        }

        private void btn14443A_Select_Click(object sender, EventArgs e)
        {
            string strTmp = "";
            byte[] buf = new byte[64];
            byte[] uid = new byte[16];
            string strUid = tb14443A_uid.Text;

            if (String.IsNullOrEmpty(strUid))
            {
                tb14443A_message.Text += "\r\nThere is no card being selected!\r\n";
                return;
            }
            else
            {
                //strTmp = CPublic.StrToHexStr(tb14443A_uid.Text);
                //uid = CPublic.CharToByte(strTmp);
                uid = CPublic.CharToByte(tb14443A_uid.Text);
                byte len = (byte)tb14443A_uid.TextLength;
                //MessageBox.Show(tb14443A_uid.TextLength.ToString());

                int ret = reader.HID_Select_14443A(ref uid[0], len, ref buf[0]);
                if (ret == 0)
                {
                    strTmp = "";
                    for (int i = 0; i < buf[0]; i++)
                    {
                        strTmp += buf[i + 1].ToString("X2");
                    }

                    tb14443A_message.Text += "\r\nSelected card serial number is " + strTmp;
                    tb14443A_message.Text += "\r\n";
                }
                else if (ret == -1)
                {
                    tb14443A_message.Text += "\r\nThe device is not opened !\r\n";
                }
                else
                {
                    tb14443A_message.Text += CPublic.ShowError(ret, ref buf[0]);
                }
            }

        }

        private void btn14443A_halt_Click(object sender, EventArgs e)
        {
            int ret = reader.HID_Halt_14443A();
            if (ret == 0)
            {
                tb14443A_message.Text += "\r\nHalt operation success !\r\n";
            }
            else if (ret == -1)
            {
                tb14443A_message.Text += "\r\nThe device is not opened !\r\n";
            }
            else
            {
                tb14443A_message.Text += CPublic.ApiError(ret);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String strTmp = null;
            byte[] buf = new byte[64];
            byte flag = 2;

            byte mode = (byte)cob14443A_mode_get.SelectedIndex;
            byte halt = (byte)cob14443A_halt.SelectedIndex;

            int ret = reader.HID_GetSerialNum_14443A(mode, halt, ref flag, ref buf[0]);
            if (ret == 0)
            {
                if (flag == 0)
                {
                    tb14443A_message.Text += "\r\nThere is only one card !\r\n";
                }
                else if (flag == 1)
                {
                    tb14443A_message.Text += "\r\nThere are multiple cards !\r\n";
                }
                else if (flag == 2)
                {
                    tb14443A_message.Text += "\r\nMaybe the initial flag value is 2 !\r\n";
                }
                else
                {
                    tb14443A_message.Text += "\r\nUnknown reason !\r\n";
                }

                for (int i = 0; i < buf[0]; i++)
                {
                    strTmp += string.Format("{0:X2}", buf[i + 1]);
                }

                tb14443A_message.Text += "\r\nThe card' serial number is " + strTmp;
                tb14443A_message.AppendText("\r\n");
            }
            else if (ret == -1)
            {
                tb14443A_message.Text += "\r\nThe device is not opened !\r\n";
            }
            else
            {
                tb14443A_message.Text += CPublic.ShowError(ret, ref buf[0]);
            }

        }

        private void btn14443A_read_Click(object sender, EventArgs e)
        {
            String strTmp = null;
            byte[] buf = new byte[128];
            byte[] key = new byte[8];

            byte mode = (byte)cob14443A_mode_wr.SelectedIndex;
            byte blockaddress = (byte)cob14443A_block_address.SelectedIndex;
            byte blocknum = (byte)(cob14443A_block_num.SelectedIndex + 1);

            key = CPublic.CharToByte(tb14443A_key.Text);
            int ret = 0;

            if (rbMifare.Checked)
            {
                ret = reader.HID_Read_14443A(mode, blockaddress, blocknum, ref key[0], ref buf[0]);
                if (ret == 0)
                {
                
                    for (int i = 0; i < key[0]; i++)
                    {
                        strTmp += string.Format("{0:X2}", key[i + 1]);
                    }

                    tb14443A_message.Text += "\r\nThe card' serial number is " + strTmp;
                    tb14443A_message.AppendText("\r\n");

                    strTmp = null;
                    for (int i = 0; i < 16 * blocknum; i++)
                    {
                        strTmp += string.Format("{0:X2}", buf[i]);
                    }

                    tb14443A_message.Text += "\r\nReceived data from card is " + strTmp;
                    tb14443A_message.AppendText("\r\n");
                }
                else if (ret == -1)
                {
                    tb14443A_message.Text += "\r\nThe device is not opened !\r\n";
                }
                else
                {
                    tb14443A_message.Text += CPublic.ShowError(ret, ref buf[0]);
                }
            }
            else //Ultralight
            {
                mode = 1;
                blocknum = 0x01;

                ret = reader.HID_Read_Ultralight(mode, blocknum, blockaddress, ref buf[0]);
                if (ret == 0)
                {
                    int len = buf[0];

                    strTmp = null;
                    for (int i = 0; i < len; i++)
                    {
                        strTmp += string.Format("{0:X2}", buf[i + 1]);
                    }

                    tb14443A_message.Text += "\r\nReceived data from card is " + strTmp;
                    tb14443A_message.AppendText("\r\n");
                }
                else if (ret == -1)
                {
                    tb14443A_message.Text += "\r\nThe device is not opened !\r\n";
                }
                else
                {
                    tb14443A_message.Text += CPublic.ShowError(ret, ref buf[0]);
                }
            }
            
        }

        private void btn14443A_write_Click(object sender, EventArgs e)
        {
            String strTmp = null;
            byte[] buf = new byte[64];
            byte[] key = new byte[8];
            byte[] text = new byte[128];

            byte mode = (byte)cob14443A_mode_wr.SelectedIndex;
            byte blockaddress = (byte)cob14443A_block_address.SelectedIndex;
            byte blocknum = (byte)(cob14443A_block_num.SelectedIndex + 1);

            key = CPublic.CharToByte(tb14443A_key.Text);
            text = CPublic.CharToByte(tb14443A_data.Text);

            int ret = 0;
            if (rbMifare.Checked)
            {
                ret = reader.HID_Write_14443A(mode, blockaddress, blocknum, ref key[0], ref text[0], ref buf[0]);
                if (ret == 0)
                {
                    for (int i = 0; i < buf[0]; i++)
                    {
                        strTmp += string.Format("{0:X2}", buf[i + 1]);
                    }

                    tb14443A_message.Text += "\r\nThe card' serial number is " + strTmp;
                    tb14443A_message.AppendText("\r\n");
                }
                else if (ret == -1)
                {
                    tb14443A_message.Text += "\r\nThe device is not opened !\r\n";
                }
                else
                {
                    tb14443A_message.Text += CPublic.ShowError(ret, ref buf[0]);
                }
            }
            else
            {
                mode = 1;
                blocknum = 1;

                buf = CPublic.CharToByte(tb14443A_data.Text);

                ret = reader.HID_Write_Ultralight(mode, blocknum, blockaddress, ref buf[0]);
                if (ret == 0)
                {
                    for (int i = 0; i < buf[0]; i++)
                    {
                        strTmp += string.Format("{0:X2}", buf[i + 1]);
                    }

                    tb14443A_message.Text += "\r\nThe card' serial number is " + strTmp;
                    tb14443A_message.AppendText("\r\n");
                }
                else if (ret == -1)
                {
                    tb14443A_message.Text += "\r\nThe device is not opened !\r\n";
                }
                else
                {
                    tb14443A_message.Text += CPublic.ShowError(ret, ref buf[0]);
                }
            }
            
        }

        private void btn14443A_initial_Click(object sender, EventArgs e)
        {
            String strTmp = null;
            byte[] buf = new byte[16];
            byte[] key = new byte[8];
            int EP_value;

            byte mode = (byte)cob14443A_mode_ep.SelectedIndex;
            byte sector = (byte)cob14443A_sector.SelectedIndex;

            key = CPublic.CharToByte(tb14443A_key_ep.Text);
            EP_value = CPublic.HexStringToInt(CPublic.StrToHexStr(tb14443A_value.Text));

            int ret = reader.HID_InitEP_14443A(mode, sector, ref key[0], EP_value, ref buf[0]);
            if (ret == 0)
            {
                for (int i = 0; i < buf[0]; i++)
                {
                    strTmp += string.Format("{0:X2}", buf[i + 1]);
                }

                tb14443A_message.Text += "\r\nThe card' serial number is " + strTmp;
                tb14443A_message.AppendText("\r\n");
            }
            else if (ret == -1)
            {
                tb14443A_message.Text += "\r\nThe device is not opened !\r\n";
            }
            else
            {
                tb14443A_message.Text += CPublic.ShowError(ret, ref buf[0]);
            }
        }

        private void btn14443A_increment_Click(object sender, EventArgs e)
        {
            String strTmp = null;
            byte[] buf = new byte[16];
            byte[] key = new byte[8];
            int EP_value;

            byte mode = (byte)cob14443A_mode_ep.SelectedIndex;
            byte sector = (byte)cob14443A_sector.SelectedIndex;

            key = CPublic.CharToByte(tb14443A_key_ep.Text);
            EP_value = CPublic.HexStringToInt(CPublic.StrToHexStr(tb14443A_value.Text));

            int ret = reader.HID_IncreaseEP_14443A(mode, sector, ref key[0], ref EP_value, ref buf[0]);
            if (ret == 0)
            {
                for (int i = 0; i < buf[0]; i++)
                {
                    strTmp += string.Format("{0:X2}", buf[i + 1]);
                }

                tb14443A_message.Text += "\r\nThe card' serial number is " + strTmp;
                tb14443A_message.AppendText("\r\n");

                strTmp = EP_value.ToString("X2");

                tb14443A_message.Text += "\r\nReceived data from card is \r\n" + strTmp;
                tb14443A_message.AppendText("\r\n");
            }
            else if (ret == -1)
            {
                tb14443A_message.Text += "\r\nThe device is not opened !\r\n";
            }
            else
            {
                tb14443A_message.Text += CPublic.ShowError(ret, ref buf[0]);
            }
        }

        private void btn14443A_decrement_Click(object sender, EventArgs e)
        {
            String strTmp = null;
            byte[] buf = new byte[16];
            byte[] key = new byte[8];
            int EP_value;

            byte mode = (byte)cob14443A_mode_ep.SelectedIndex;
            byte sector = (byte)cob14443A_sector.SelectedIndex;

            key = CPublic.CharToByte(tb14443A_key_ep.Text);
            EP_value = CPublic.HexStringToInt(CPublic.StrToHexStr(tb14443A_value.Text));

            int ret = reader.HID_DecreaseEP_14443A(mode, sector, ref key[0], ref EP_value, ref buf[0]);
            if (ret == 0)
            {
                for (int i = 0; i < buf[0]; i++)
                {
                    strTmp += string.Format("{0:X2}", buf[i + 1]);
                }

                tb14443A_message.Text += "\r\nThe card' serial number is " + strTmp;
                tb14443A_message.AppendText("\r\n");

                strTmp = EP_value.ToString("X2");

                tb14443A_message.Text += "\r\nReceived data from card is \r\n" + strTmp;
                tb14443A_message.AppendText("\r\n");
            }
            else if (ret == -1)
            {
                tb14443A_message.Text += "\r\nThe device is not opened !\r\n";
            }
            else
            {
                tb14443A_message.Text += CPublic.ShowError(ret, ref buf[0]);
            }
        }

        private void btn14443A_send_Click(object sender, EventArgs e)
        {
            String strTmp = null;
            byte[] buf = new byte[64];
            byte[] length = new byte[2];
            byte[] cmd = new byte[64];

            byte crc = (byte)cob14443A_crc.SelectedIndex;
            length[0] = (byte)CPublic.HexStringToInt(CPublic.StrToHexStr(tb14443A_length.Text));
            cmd = CPublic.CharToByte(tb14443A_cmd.Text);

            int ret = reader.HID_TFCMD_14443A(crc, ref cmd[0], ref length[0], ref buf[0]);
            if (ret == 0)
            {
                for (int i = 0; i < length[0]; i++)
                {
                    strTmp += string.Format("{0:X2}", buf[i]);
                }

                tb14443A_message.Text += "\r\nReceived data from card is \r\n" + strTmp;
                tb14443A_message.AppendText("\r\n");
            }
            else if (ret == -1)
            {
                tb14443A_message.Text += "\r\nThe device is not opened !\r\n";
            }
            else
            {
                tb14443A_message.Text += CPublic.ShowError(ret, ref buf[0]);
            }
        }

        private void btn_setparam_open_Click(object sender, EventArgs e)
        {
            int device_num = 0;

            int ret = reader.GetHIDDevice(ref device_num);
            if (ret == 0)
            {
                ret = reader.OpenHIDDevice(device_num - 1);
                if (ret == 0)
                {
                    if (IntPtr.Zero != reader.GetHIDHandle())
                    {
                        tb_sp_message.Text += "\r\nOpen success!\r\n";
                        btn_sp_open.Enabled = false;
                        btn_sp_close.Enabled = true;
                    }
                    else
                    {
                        tb_sp_message.Text += "\r\nOpen Failure!\r\n";
                    }
                }
                else if (ret == -1)
                {
                    tb_sp_message.AppendText("\r\nThere is no HID device !!\r\n");
                }
                else
                {
                    tb_sp_message.Text += "\r\nUnknown error!!\r\n";
                }
            }
            else if (ret == -1)
            {
                tb_sp_message.AppendText("\r\nThere is no HID device !\r\n");
            }
            else
            {
                tb_sp_message.Text += "\r\nUnknown error !\r\n";
            }
        }

        private void btn_setparam_close_Click(object sender, EventArgs e)
        {
            int status = reader.CloseHIDPort();
            if (status == 0)
            {
                tb_sp_message.Text += "\r\nClose success !\r\n";
                btn_sp_close.Enabled = false;
                btn_sp_open.Enabled = true;
            }
            else if (status == -1)
            {
                tb_sp_message.Text += "\r\nClose Failure !\r\n";
            }
            else if (status == -2)
            {
                tb_sp_message.Text += "\r\nPrevious opening is failing !\r\n";
            }
            else
            {
                tb_sp_message.Text += "\r\nUnknown error !\r\n";
            }
        }

        private void btn_setparam_read_Click(object sender, EventArgs e)
        {
            if (IntPtr.Zero != reader.GetHIDHandle())
            {
                string strTmp = "";
                byte[] buf = new byte[64];

                int deviceAddress = CPublic.HexStringToInt(cob_sp_address.Text);
                if (deviceAddress < 0 || deviceAddress > 255)
                {
                    tb_sp_message.Text += "\r\nDevice address must between 0X00-0XFF !\r\n";
                    return;
                }

                int ret = reader.GetHIDSerNum(deviceAddress, ref buf[0]);
                if (ret == 0)
                {
                    for (int i = 0; i < 8; i++)
                    {
                        strTmp += buf[i + 1].ToString("X2") + " ";
                    }

                    tb_sp_message.Text += "\r\nVersion is " + strTmp;
                    tb_sp_message.Text += "\r\n";
                }
                else
                {
                    tb_sp_message.Text += "\r\nGet version error !\r\n";
                    tb_sp_message.Text += "\r\nAPI error:" + CPublic.ApiError(ret) +
                        "Return error:" + CPublic.ReturnCodeError(ref buf[0]);
                }
            }
            else
            {
                tb_sp_message.Text += "\r\nThe device is not opened !\r\n";
            }
        }

        private void btn_setparam_setaddress_Click(object sender, EventArgs e)
        {
            byte[] buf = new byte[16];
            int NewAddress = CPublic.HexStringToInt(cob_sp_address.Text);
            if (NewAddress < 0 || NewAddress > 255)
            {
                tb_sp_message.Text += "\r\nDevice address must between 0X00-0XFF !\r\n";
            }

            int ret = reader.SetHIDAddress(NewAddress, ref buf[0]);
            if (ret == 0)
            {
                tb_sp_message.Text += "\r\nSet Device address success !\r\n";
            }
            else if (ret == -1)
            {
                tb_sp_message.Text += "\r\nThe device is not opened !\r\n";
            }
            else if (ret == -2)
            {
                tb_sp_message.Text += "\r\nDeviceAddress need change !\r\n";
            }
            else
            {
                tb_sp_message.Text += "\r\nSet Device address error !\r\n";
                //tb_sp_message.Text += "\r\n API error:" + CPublic.ApiError(ret) +"Return error:" + CPublic.ReturnCodeError(ref buf[0]);
                tb_sp_message.Text += CPublic.ShowError(ret, ref buf[0]);
            }

        }

        private void btn_sp_led_set_Click(object sender, EventArgs e)
        {
            byte[] buf = new byte[16];
            byte led_time = (byte)CPublic.HexStringToInt(tb_sp_led_time.Text);
            byte led_num = (byte)CPublic.HexStringToInt(tb_sp_led_num.Text);

            int ret = reader.SetHIDLED(led_time, led_num, ref buf[0]);
            if (ret == 0)
            {
                tb_sp_message.Text += "\r\nSet LED success !\r\n";
            }
            else if (ret == -1)
            {
                tb_sp_message.Text += "\r\nThe device is not opened !\r\n";
            }
            else if (ret == -2)
            {
                tb_sp_message.Text += "\r\nLed time Param need between 0X00-0X32 !\r\n";
            }
            else
            {
                tb_sp_message.Text += CPublic.ShowError(ret, ref buf[0]);
            }
        }

        private void btn_sp_buzzer_set_Click(object sender, EventArgs e)
        {
            byte[] buf = new byte[16];
            byte buzzer_time = (byte)CPublic.HexStringToInt(tb_sp_buzzer_time.Text);
            byte buzzer_num = (byte)CPublic.HexStringToInt(tb_sp_buzzer_num.Text);

            int ret = reader.SetHIDBuzzer(buzzer_time, buzzer_num, ref buf[0]);
            if (ret == 0)
            {
                tb_sp_message.Text += "\r\nSet Buzzer success !\r\n";
            }
            else if (ret == -1)
            {
                tb_sp_message.Text += "\r\nThe device is not opened !\r\n";
            }
            else if (ret == -2)
            {
                tb_sp_message.Text += "\r\nBuzzer time Param need between 0X00-0X32 !\r\n";
            }
            else
            {
                tb_sp_message.Text += CPublic.ShowError(ret, ref buf[0]);
            }
        }

        private void tb_sp_message_TextChanged(object sender, EventArgs e)
        {
            tb_sp_message.SelectionStart = tb_sp_message.Text.Length;

            tb_sp_message.ScrollToCaret();
        }

        private void tb14444A_message_TextChanged(object sender, EventArgs e)
        {
            tb14443A_message.SelectionStart = tb14443A_message.Text.Length;

            tb14443A_message.ScrollToCaret();
        }

        private void rbMifare_CheckedChanged(object sender, EventArgs e)
        {
            cob14443A_mode_wr.Enabled = true;
            tb14443A_key.Enabled = true;
        }

        private void rbUltralight_CheckedChanged(object sender, EventArgs e)
        {
            cob14443A_mode_wr.Enabled = false;
            tb14443A_key.Enabled = false;
        }

        private void cob14443A_block_num_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (rbUltralight.Checked)
            {
                if (cob14443A_block_num.SelectedIndex != 0)
                {
                    MessageBox.Show("Could Only Read/Write One Page!");
                    cob14443A_block_num.SelectedIndex = 0;
                }
            }
        }

    }
}