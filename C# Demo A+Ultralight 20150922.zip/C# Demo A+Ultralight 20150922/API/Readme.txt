API USB A+Ultralight V1.2 - En.doc
[20140318]
1. Modify the function "API_USBMF_PowerOn", add a parameter "buffer" which return the status code when the function failed.